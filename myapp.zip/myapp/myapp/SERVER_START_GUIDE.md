# 服务器启动指南

## 重要提示

**这些命令必须在阿里云服务器上执行，不能在本地电脑上运行！**

---

## 一、如何连接到阿里云服务器

### 方法1：使用宝塔面板终端（推荐）

1. 打开浏览器，访问你的宝塔面板地址
2. 登录宝塔面板
3. 点击左侧菜单的 **"终端"**
4. 现在你已经连接到服务器终端，可以执行命令了

### 方法2：使用SSH工具

#### Windows用户：

1. 下载并安装 [PuTTY](https://www.putty.org/) 或使用 PowerShell
2. 使用 PowerShell（推荐）：
   - 按 `Win + R`，输入 `powershell`，回车
   - 执行以下命令：
   ```bash
   ssh root@101.200.122.44
   ```
3. 输入服务器密码（输入时不会显示密码）

#### Mac/Linux用户：

1. 打开终端
2. 执行命令：
   ```bash
   ssh root@101.200.122.44
   ```
3. 输入服务器密码

### 方法3：使用宝塔面板的"文件"功能

1. 登录宝塔面板
2. 点击 **"文件"**
3. 进入 `/www/wwwroot/myapp` 目录
4. 点击 **"终端"** 按钮（如果有）

---

## 二、启动Node.js服务

连接到服务器后，按照以下步骤操作：

### 1. 进入项目目录

```bash
cd /www/wwwroot/myapp
```

### 2. 检查项目文件

```bash
ls -la
```

应该看到：
- server.js
- package.json
- public/
- uploads/
- database.sql
等文件

### 3. 安装依赖（如果还没安装）

```bash
npm install
```

等待安装完成...

### 4. 测试数据库连接

```bash
node test-db-connection.js
```

如果显示 "✓ 数据库连接成功！"，继续下一步。

### 5. 启动Node.js服务

```bash
pm2 start server.js --name "myapp"
```

### 6. 查看服务状态

```bash
tus
```

应该看到：
```
┌─────┬────────┬─────────────┬─────────┬─────────┬──────────┬────────┬──────┬───────────┬──────────┬──────────┐
│ id  │ name   │ namespace   │ version │ mode    │ pid      │ uptime │ ↺    │ status    │ cpu      │ mem      │
├─────┼────────┼─────────────┼─────────┼─────────┼──────────┼────────┼──────┼───────────┼──────────┼──────────┤
│ 0   │ myapp  │ default     │ 1.0.0   │ fork    │ 12345    │ 0s     │ 0    │ online    │ 0%       │ 45.2mb   │
└─────┴────────┴─────────────┴─────────┴─────────┴──────────┴────────┴──────┴───────────┴──────────┴──────────┘
```

### 7. 设置开机自启

```bash
pm2 startup
```

系统会显示一个命令，复制并执行它（类似这样）：
```bash
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u root --hp /root
```

### 8. 保存PM2配置

```bash
pm2 save
```

---

## 三、验证服务是否正常运行

### 1. 查看服务日志

```bash
pm2 logs myapp
```

应该看到：
```
[TAILING] Tailing last 15 lines for [myapp] (change the value with --lines option)
myapp | 服务器运行在 http://localhost:3000
myapp | API 文档: http://localhost:3000/api
```

按 `Ctrl + C` 退出日志查看

### 2. 测试本地连接

```bash
curl http://localhost:3000/api/posts
```

应该返回JSON格式的帖子数据。

### 3. 测试外部访问

在浏览器中访问：http://101.200.122.44

应该能看到网站首页。

---

## 四、常用PM2命令

启动后，你可以使用以下命令管理服务：

### 查看服务状态

```bash
pm2 status
```

### 查看服务日志

```bash
pm2 logs myapp
```

### 重启服务

```bash
pm2 restart myapp
```

### 停止服务

```bash
pm2 stop myapp
```

### 删除服务

```bash
pm2 delete myapp
```

### 监控服务

```bash
pm2 monit
```

### 查看服务详情

```bash
pm2 show myapp
```

### 清空日志

```bash
pm2 flush
```

---

## 五、故障排查

### 问题1：pm2命令不存在

**症状**：执行 `pm2` 命令时显示 "command not found"

**解决方法**：
```bash
npm install -g pm2
```

### 问题2：端口3000已被占用

**症状**：启动服务时显示端口错误

**解决方法**：
```bash
# 查找占用3000端口的进程
lsof -i :3000

# 或
netstat -tlnp | grep :3000

# 杀死占用端口的进程
kill -9 <进程ID>

# 然后重新启动服务
pm2 restart myapp
```

### 问题3：服务启动后立即停止

**症状**：`pm2 status` 显示服务状态为 "stopped"

**解决方法**：
```bash
# 查看错误日志
pm2 logs myapp --err

# 检查数据库连接
node test-db-connection.js

# 重新启动
pm2 restart myapp
```

### 问题4：无法访问网站

**检查清单**：

1. 确认Node.js服务正在运行：
   ```bash
   pm2 status
   ```

2. 确认Nginx正在运行：
   ```bash
   systemctl status nginx
   ```

3. 确认防火墙端口已开放：
   - 阿里云控制台 -> 安全组 -> 确认80和3000端口已开放
   - 宝塔面板 -> 安全 -> 确认80和3000端口已放行

4. 测试本地连接：
   ```bash
   curl http://localhost
   curl http://localhost:3000/api/posts
   ```

---

## 六、完整启动流程（一次性执行）

如果你已经安装了依赖，可以直接复制以下命令块一次性执行：

```bash
# 进入项目目录
cd /www/wwwroot/myapp

# 停止旧服务（如果存在）
pm2 stop myapp
pm2 delete myapp

# 启动新服务
pm2 start server.js --name "myapp"

# 查看状态
pm2 status

# 查看日志（按Ctrl+C退出）
pm2 logs myapp

# 设置开机自启（只需执行一次）
pm2 startup

# 复制输出的命令并执行，例如：
# sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u root --hp /root

# 保存配置
pm2 save

# 验证服务
curl http://localhost:3000/api/posts
```

---

## 七、部署后的验证

### 1. 在服务器上测试

```bash
curl http://101.200.122.44
```

### 2. 在本地浏览器测试

打开浏览器，访问：
- 主页：http://101.200.122.44
- 管理后台：http://101.200.122.44/admin.html
- API：http://101.200.122.44/api/posts

### 3. 测试发布功能

1. 访问 http://101.200.122.44
2. 填写用户名和内容
3. 点击"发布动态"
4. 检查是否成功显示新帖子

---

## 八、常见问题

### Q1: 我应该在哪里执行这些命令？

**A**: 必须在阿里云服务器的终端中执行，不能在本地电脑的命令行中执行。使用以下任一方式连接到服务器：
- 宝塔面板的"终端"功能
- SSH工具（PuTTY、PowerShell等）
- 宝塔面板的"文件"功能中的终端按钮

### Q2: 我需要每次重启服务器都手动启动吗？

**A**: 不需要。执行了 `pm2 startup` 和 `pm2 save` 后，服务会自动开机启动。

### Q3: 如何停止服务？

**A**: 执行 `pm2 stop myapp` 停止服务，执行 `pm2 delete myapp` 完全删除服务。

### Q4: 如何查看服务的实时日志？

**A**: 执行 `pm2 logs myapp` 查看实时日志，按 `Ctrl + C` 退出。

### Q5: 服务器重启后服务没有自动启动？

**A**: 执行以下命令：
```bash
pm2 resurrect
pm2 save
```

---

## 九、联系支持

如果遇到问题，请提供以下信息：

1. PM2状态：`pm2 status` 的输出
2. 服务日志：`pm2 logs myapp --lines 50` 的输出
3. Nginx状态：`systemctl status nginx` 的输出
4. 数据库连接测试：`node test-db-connection.js` 的输出

---

**文档版本**: 1.0  
**更新日期**: 2026年1月18日
