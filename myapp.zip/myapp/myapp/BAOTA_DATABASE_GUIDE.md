# 🔧 宝塔面板数据库连接指南

## 📋 步骤 1: 在宝塔面板创建数据库

### 1.1 登录宝塔面板
访问你的宝塔面板地址（通常是：http://你的服务器IP:8888）

### 1.2 创建数据库
1. 点击左侧菜单 **"数据库"**
2. 点击 **"添加数据库"** 按钮
3. 填写以下信息：
   - **数据库名**: `social_platform`（或你喜欢的名字）
   - **用户名**: `social_user`（或你喜欢的名字）
   - **密码**: 点击"生成"按钮生成一个强密码（**记住这个密码！**）
   - **访问权限**: 选择 **"本地服务器"** 或 **"所有人"**
4. 点击 **"提交"** 按钮

### 1.3 记录数据库信息
创建成功后，记下以下信息（后面会用到）：
```
数据库名: social_platform
用户名: social_user
密码: [你生成的密码]
数据库地址: localhost（或 127.0.0.1）
端口: 3306
```

---

## 📋 步骤 2: 导入数据库表结构

### 方法 A: 使用宝塔面板导入（推荐）

1. 在数据库列表中，找到刚创建的数据库
2. 点击右侧的 **"管理"** 按钮（或 **"导入"**）
3. 在弹出的 phpMyAdmin 界面中：
   - 点击顶部菜单的 **"导入"**
   - 点击 **"选择文件"** 按钮
   - 选择项目中的 `database.sql` 文件
   - 点击页面底部的 **"执行"** 按钮
4. 等待导入完成，看到"导入成功"提示

### 方法 B: 使用 SQL 命令导入

1. 在数据库列表中，点击数据库的 **"管理"** 按钮
2. 进入 phpMyAdmin 界面
3. 点击顶部菜单的 **"SQL"**
4. 复制 `database.sql` 文件中的所有 SQL 语句
5. 粘贴到文本框中
6. 点击 **"执行"** 按钮

### 方法 C: 使用命令行导入（如果可以 SSH 登录）

```bash
# 登录服务器
ssh root@你的服务器IP

# 导入数据库
mysql -u social_user -p social_platform < /var/www/myapp/database.sql

# 输入密码后等待导入完成
```

---

## 📋 步骤 3: 修改 server.js 配置

### 3.1 打开 server.js 文件
在项目目录中找到 `server.js` 文件，用文本编辑器打开

### 3.2 找到数据库配置部分
找到第 35-40 行左右的数据库配置：

```javascript
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '0000',
    database: 'social_platform',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});
```

### 3.3 修改为你的宝塔数据库信息
将上面的配置修改为：

```javascript
const pool = mysql.createPool({
    host: 'localhost',              // 数据库地址（通常是 localhost）
    user: 'social_user',            // ← 改为你的数据库用户名
    password: '你的数据库密码',      // ← 改为你在宝塔生成的密码
    database: 'social_platform',    // ← 改为你的数据库名
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});
```

**重要提示**：
- `host`: 如果数据库和网站在同一台服务器，使用 `localhost` 或 `127.0.0.1`
- `user`: 填写宝塔面板创建数据库时设置的用户名
- `password`: 填写宝塔面板生成的密码（一定要准确！）
- `database`: 填写数据库名称

---

## 📋 步骤 4: 测试数据库连接

### 4.1 在本地测试（如果是在本地开发）

1. 确保本地 MySQL 正在运行
2. 运行项目：
   ```bash
   npm install
   node server.js
   ```
3. 看到以下提示说明连接成功：
   ```
   🚀 服务器运行在 http://localhost:3000
   📊 API 文档: http://localhost:3000/api
   ```

### 4.2 在服务器测试（如果部署到服务器）

1. 上传修改后的 `server.js` 到服务器
2. SSH 登录服务器：
   ```bash
   ssh root@你的服务器IP
   cd /var/www/myapp
   ```
3. 重启服务：
   ```bash
   pm2 restart social-platform
   # 或如果没有用 PM2
   node server.js
   ```
4. 查看日志：
   ```bash
   pm2 logs social-platform
   ```

---

## 📋 步骤 5: 验证数据库连接

### 5.1 测试 API 接口

在浏览器中访问：
```
http://你的服务器IP/api/posts
```

如果看到类似这样的 JSON 响应，说明数据库连接成功：
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "user_id": 1,
      "username": "张三",
      "content": "今天天气真好！",
      "likes_count": 0,
      "comments_count": 0,
      "created_at": "2024-01-10T12:00:00.000Z"
    }
  ]
}
```

### 5.2 测试发布动态

1. 访问主页面：http://你的服务器IP/
2. 填写用户名和内容
3. 点击"发布"按钮
4. 如果看到"发布成功"提示，说明数据库连接完全正常！

---

## 🔍 常见问题

### 问题 1: 连接数据库失败 - "Access denied for user"

**原因**: 数据库用户名或密码错误

**解决方法**:
1. 登录宝塔面板 → 数据库
2. 找到对应的数据库，点击 **"修改"** 或 **"密码"**
3. 重新生成密码或查看现有密码
4. 更新 `server.js` 中的密码配置
5. 重启服务器

### 问题 2: 连接数据库失败 - "Unknown database"

**原因**: 数据库名称错误或数据库未创建

**解决方法**:
1. 登录宝塔面板 → 数据库
2. 确认数据库名称是否正确
3. 如果数据库不存在，重新创建
4. 导入 `database.sql` 文件

### 问题 3: 数据库连接超时

**原因**: 防火墙阻止了数据库连接

**解决方法**:
1. 登录宝塔面板 → 安全
2. 添加放行端口 3306
3. 或在服务器防火墙中开放端口：
   ```bash
   sudo ufw allow 3306
   ```

### 问题 4: 导入 database.sql 失败

**原因**: SQL 文件格式或权限问题

**解决方法**:
1. 确认 `database.sql` 文件编码为 UTF-8
2. 使用 phpMyAdmin 的"导入"功能
3. 如果还是失败，可以手动复制 SQL 语句到 phpMyAdmin 的 SQL 界面执行

---

## 📊 查看数据库内容

### 使用宝塔面板 phpMyAdmin

1. 登录宝塔面板 → 数据库
2. 点击数据库的 **"管理"** 按钮
3. 进入 phpMyAdmin 界面
4. 可以查看和操作所有表：
   - `users` - 用户表
   - `posts` - 帖子表
   - `comments` - 评论表
   - `likes` - 点赞表

### 使用命令行

```bash
# 登录 MySQL
mysql -u social_user -p

# 输入密码后：
use social_platform;

# 查看所有表
SHOW TABLES;

# 查看帖子
SELECT * FROM posts;

# 查看用户
SELECT * FROM users;

# 退出
EXIT;
```

---

## 🔄 备份和恢复数据库

### 备份数据库

#### 方法 A: 使用宝塔面板（推荐）
1. 宝塔面板 → 数据库
2. 找到数据库，点击 **"备份"** 按钮
3. 下载备份文件

#### 方法 B: 使用命令行
```bash
mysqldump -u social_user -p social_platform > backup_$(date +%Y%m%d).sql
```

### 恢复数据库

#### 方法 A: 使用宝塔面板
1. 宝塔面板 → 数据库
2. 找到数据库，点击 **"导入"** 按钮
3. 上传备份的 SQL 文件

#### 方法 B: 使用命令行
```bash
mysql -u social_user -p social_platform < backup_20240110.sql
```

---

## 📝 配置示例

### 完整的 server.js 数据库配置示例

```javascript
const pool = mysql.createPool({
    host: 'localhost',              // 数据库地址
    user: 'social_user',            // 数据库用户名
    password: 'Abc123!@#xyz',       // 数据库密码（示例）
    database: 'social_platform',    // 数据库名称
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    charset: 'utf8mb4'              // 使用 utf8mb4 字符集支持 emoji
});
```

---

## 🎯 快速检查清单

完成配置后，确认以下几点：

- [ ] 在宝塔面板创建了数据库
- [ ] 导入了 `database.sql` 文件
- [ ] 修改了 `server.js` 中的数据库配置
- [ ] 数据库用户名、密码、数据库名都正确
- [ ] 重启了 Node.js 服务器
- [ ] 访问 `/api/posts` 能看到数据
- [ ] 可以成功发布动态

---

## 💡 提示

1. **密码安全**: 不要将数据库密码提交到 Git 仓库
2. **定期备份**: 建议每天备份数据库
3. **权限控制**: 只给数据库用户必要的权限
4. **监控日志**: 定期查看错误日志，及时发现问题

---

**配置完成后，你的社交平台就可以正常使用了！** 🎉
