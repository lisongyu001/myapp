const mysql = require('mysql2/promise');

// 数据库连接配置
const dbConfig = {
    host: 'localhost',
    user: 'www_lisongyu_top',
    password: 'lsy@2004',
    database: 'www_lisongyu_top'
};

console.log('正在测试数据库连接...');
console.log('配置信息:', {
    host: dbConfig.host,
    user: dbConfig.user,
    database: dbConfig.database,
    password: '***'
});

async function testConnection() {
    try {
        // 创建连接
        const connection = await mysql.createConnection(dbConfig);
        console.log('✓ 数据库连接成功！');

        // 测试查询
        const [rows] = await connection.execute('SELECT VERSION() as version');
        console.log('✓ MySQL版本:', rows[0].version);

        // 检查数据库表
        const [tables] = await connection.execute('SHOW TABLES');
        console.log('✓ 数据库表:', tables.map(t => Object.values(t)[0]).join(', '));

        // 检查posts表数据
        const [posts] = await connection.execute('SELECT COUNT(*) as count FROM posts');
        console.log('✓ 帖子数量:', posts[0].count);

        // 检查users表数据
        const [users] = await connection.execute('SELECT COUNT(*) as count FROM users');
        console.log('✓ 用户数量:', users[0].count);

        // 关闭连接
        await connection.end();
        console.log('✓ 连接已关闭');
        console.log('\n数据库连接测试完成！一切正常。');

    } catch (error) {
        console.error('✗ 数据库连接失败！');
        console.error('错误信息:', error.message);
        console.error('\n请检查：');
        console.error('1. MySQL服务是否正在运行');
        console.error('2. 数据库配置是否正确');
        console.error('3. 数据库用户权限是否足够');
        console.error('4. 数据库是否存在');
        process.exit(1);
    }
}

testConnection();
