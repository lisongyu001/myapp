const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static('uploads'));
app.use(express.static('public'));

// 创建上传目录
if (!fs.existsSync('uploads')) {
    fs.mkdirSync('uploads');
}

// 配置文件上传
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
    fileFilter: (req, file, cb) => {
        const allowedTypes = /jpeg|jpg|png|gif|webp/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);

        if (mimetype && extname) {
            return cb(null, true);
        } else {
            cb(new Error('只允许上传图片文件！'));
        }
    }
});

// 数据库连接池
const pool = mysql.createPool({
    host: 'localhost',
    user: 'www_lisongyu_top',
    password: 'lsy@2004',
    database: 'www_lisongyu_top',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});


// ==================== API 路由 ====================

// 获取所有帖子
app.get('/api/posts', async (req, res) => {
    try {
        const [posts] = await pool.query(
            'SELECT * FROM posts ORDER BY created_at DESC'
        );
        res.json({ success: true, data: posts });
    } catch (error) {
        console.error('获取帖子失败:', error);
        res.status(500).json({ success: false, message: '获取帖子失败' });
    }
});

// 获取单个帖子
app.get('/api/posts/:id', async (req, res) => {
    try {
        const [posts] = await pool.query(
            'SELECT * FROM posts WHERE id = ?',
            [req.params.id]
        );

        if (posts.length === 0) {
            return res.status(404).json({ success: false, message: '帖子不存在' });
        }

        res.json({ success: true, data: posts[0] });
    } catch (error) {
        console.error('获取帖子失败:', error);
        res.status(500).json({ success: false, message: '获取帖子失败' });
    }
});

// 创建新帖子
app.post('/api/posts', upload.single('image'), async (req, res) => {
    try {
        const { username, avatar_url, content } = req.body;

        if (!username || !content) {
            return res.status(400).json({ success: false, message: '用户名和内容不能为空' });
        }

        // 检查或创建用户
        let [users] = await pool.query('SELECT id FROM users WHERE username = ?', [username]);
        let userId;

        if (users.length === 0) {
            const [result] = await pool.query(
                'INSERT INTO users (username, avatar_url) VALUES (?, ?)',
                [username, avatar_url || null]
            );
            userId = result.insertId;
        } else {
            userId = users[0].id;
        }

        // 创建帖子
        const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;
        const [result] = await pool.query(
            'INSERT INTO posts (user_id, username, avatar_url, content, image_url) VALUES (?, ?, ?, ?, ?)',
            [userId, username, avatar_url || null, content, imageUrl]
        );

        const [newPost] = await pool.query('SELECT * FROM posts WHERE id = ?', [result.insertId]);

        res.json({ success: true, data: newPost[0], message: '发布成功！' });
    } catch (error) {
        console.error('创建帖子失败:', error);
        res.status(500).json({ success: false, message: '发布失败' });
    }
});

// 删除帖子
app.delete('/api/posts/:id', async (req, res) => {
    try {
        const [result] = await pool.query('DELETE FROM posts WHERE id = ?', [req.params.id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: '帖子不存在' });
        }

        res.json({ success: true, message: '删除成功' });
    } catch (error) {
        console.error('删除帖子失败:', error);
        res.status(500).json({ success: false, message: '删除失败' });
    }
});

// 点赞帖子
app.post('/api/posts/:id/like', async (req, res) => {
    try {
        const { username } = req.body;
        const postId = req.params.id;

        if (!username) {
            return res.status(400).json({ success: false, message: '用户名不能为空' });
        }

        // 获取用户ID
        let [users] = await pool.query('SELECT id FROM users WHERE username = ?', [username]);
        let userId;

        if (users.length === 0) {
            const [result] = await pool.query('INSERT INTO users (username) VALUES (?)', [username]);
            userId = result.insertId;
        } else {
            userId = users[0].id;
        }

        // 检查是否已点赞
        const [existingLike] = await pool.query(
            'SELECT id FROM likes WHERE post_id = ? AND user_id = ?',
            [postId, userId]
        );

        if (existingLike.length > 0) {
            // 取消点赞
            await pool.query('DELETE FROM likes WHERE post_id = ? AND user_id = ?', [postId, userId]);
            await pool.query('UPDATE posts SET likes_count = likes_count - 1 WHERE id = ?', [postId]);
            res.json({ success: true, liked: false, message: '已取消点赞' });
        } else {
            // 添加点赞
            await pool.query('INSERT INTO likes (post_id, user_id) VALUES (?, ?)', [postId, userId]);
            await pool.query('UPDATE posts SET likes_count = likes_count + 1 WHERE id = ?', [postId]);
            res.json({ success: true, liked: true, message: '点赞成功' });
        }
    } catch (error) {
        console.error('点赞失败:', error);
        res.status(500).json({ success: false, message: '操作失败' });
    }
});

// 获取帖子的评论
app.get('/api/posts/:id/comments', async (req, res) => {
    try {
        const [comments] = await pool.query(
            'SELECT * FROM comments WHERE post_id = ? ORDER BY created_at DESC',
            [req.params.id]
        );
        res.json({ success: true, data: comments });
    } catch (error) {
        console.error('获取评论失败:', error);
        res.status(500).json({ success: false, message: '获取评论失败' });
    }
});

// 添加评论
app.post('/api/posts/:id/comments', async (req, res) => {
    try {
        const { username, avatar_url, content } = req.body;
        const postId = req.params.id;

        if (!username || !content) {
            return res.status(400).json({ success: false, message: '用户名和内容不能为空' });
        }

        // 获取或创建用户
        let [users] = await pool.query('SELECT id FROM users WHERE username = ?', [username]);
        let userId;

        if (users.length === 0) {
            const [result] = await pool.query(
                'INSERT INTO users (username, avatar_url) VALUES (?, ?)',
                [username, avatar_url || null]
            );
            userId = result.insertId;
        } else {
            userId = users[0].id;
        }

        // 创建评论
        const [result] = await pool.query(
            'INSERT INTO comments (post_id, user_id, username, avatar_url, content) VALUES (?, ?, ?, ?, ?)',
            [postId, userId, username, avatar_url || null, content]
        );

        // 更新帖子评论数
        await pool.query('UPDATE posts SET comments_count = comments_count + 1 WHERE id = ?', [postId]);

        const [newComment] = await pool.query('SELECT * FROM comments WHERE id = ?', [result.insertId]);

        res.json({ success: true, data: newComment[0], message: '评论成功！' });
    } catch (error) {
        console.error('添加评论失败:', error);
        res.status(500).json({ success: false, message: '评论失败' });
    }
});

// 删除评论
app.delete('/api/comments/:id', async (req, res) => {
    try {
        const [comments] = await pool.query('SELECT post_id FROM comments WHERE id = ?', [req.params.id]);

        if (comments.length === 0) {
            return res.status(404).json({ success: false, message: '评论不存在' });
        }

        const postId = comments[0].post_id;

        await pool.query('DELETE FROM comments WHERE id = ?', [req.params.id]);
        await pool.query('UPDATE posts SET comments_count = comments_count - 1 WHERE id = ?', [postId]);

        res.json({ success: true, message: '删除成功' });
    } catch (error) {
        console.error('删除评论失败:', error);
        res.status(500).json({ success: false, message: '删除失败' });
    }
});

// 获取统计数据（用于后台管理）
app.get('/api/stats', async (req, res) => {
    try {
        const [postsCount] = await pool.query('SELECT COUNT(*) as count FROM posts');
        const [usersCount] = await pool.query('SELECT COUNT(*) as count FROM users');
        const [commentsCount] = await pool.query('SELECT COUNT(*) as count FROM comments');
        const [likesCount] = await pool.query('SELECT COUNT(*) as count FROM likes');

        res.json({
            success: true,
            data: {
                posts: postsCount[0].count,
                users: usersCount[0].count,
                comments: commentsCount[0].count,
                likes: likesCount[0].count
            }
        });
    } catch (error) {
        console.error('获取统计数据失败:', error);
        res.status(500).json({ success: false, message: '获取统计数据失败' });
    }
});

// 获取所有用户（用于后台管理）
app.get('/api/users', async (req, res) => {
    try {
        const [users] = await pool.query('SELECT * FROM users ORDER BY created_at DESC');
        res.json({ success: true, data: users });
    } catch (error) {
        console.error('获取用户失败:', error);
        res.status(500).json({ success: false, message: '获取用户失败' });
    }
});

// 启动服务器
app.listen(PORT, '0.0.0.0', () => {
    console.log(` 服务器运行在 http://localhost:3000`);
    console.log(`API 文档: http://localhost:3000/api`);
});

// 优雅关闭
process.on('SIGINT', async () => {
    console.log('\n正在关闭服务器...');
    await pool.end();
    process.exit(0);
});
