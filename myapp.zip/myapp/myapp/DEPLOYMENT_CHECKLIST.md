# 项目部署检查清单

## 项目概述
- **项目名称**: 社交平台（Apple风格）
- **部署环境**: 阿里云服务器 + 宝塔面板
- **数据库**: MySQL (www_lisongyu_top)
- **后端端口**: 3000
- **前端端口**: 80 (通过Nginx)

## 数据库配置

### 当前数据库连接信息
```javascript
{
    host: 'localhost',
    user: 'rwww_lisongyu_top',
    password: 'lsy@2004',
    database: 'www_lisongyu_top'
}
```

### 数据库表结构
- `users` - 用户表
- `posts` - 帖子表
- `comments` - 评论表
- `likes` - 点赞表

### 数据库初始化步骤
1. 登录宝塔面板
2. 进入数据库管理
3. 执行 `database.sql` 文件中的SQL语句
4. 验证表是否创建成功

## 后端配置

### 依赖包
```json
{
  "express": "^4.18.2",
  "mysql2": "^3.6.5",
  "cors": "^2.8.5",
  "multer": "^1.4.5-lts.1"
}
```

### 启动命令
```bash
# 开发环境
npm run dev

# 生产环境
npm start
```

### 后端API接口
- `GET /api/posts` - 获取所有帖子
- `GET /api/posts/:id` - 获取单个帖子
- `POST /api/posts` - 创建新帖子（支持图片上传）
- `DELETE /api/posts/:id` - 删除帖子
- `POST /api/posts/:id/like` - 点赞/取消点赞
- `GET /api/posts/:id/comments` - 获取评论
- `POST /api/posts/:id/comments` - 添加评论
- `DELETE /api/comments/:id` - 删除评论
- `GET /api/stats` - 获取统计数据
- `GET /api/users` - 获取所有用户

## 前端配置

### 文件结构
```
public/
├── index.html      # 主页面
├── admin.html      # 管理页面
├── login.html      # 登录页面
├── app.js          # 主页面逻辑
├── admin.js        # 管理页面逻辑
├── styles.css      # 样式文件
└── login.css       # 登录页面样式
```

### API调用配置
```javascript
const API_BASE_URL = `${window.location.protocol}//${window.location.hostname}/api`;
```

## Nginx配置

### 配置文件位置
- 服务器IP: 101.200.122.44
- 配置文件: `/www/server/panel/vhost/nginx/101.200.122.44.conf`

### 关键配置
```nginx
server {
    listen 80;
    server_name 101.200.122.44;
    
    # 静态文件服务
    location / {
        root /var/www/myapp/public;
        try_files $uri $uri/ /index.html;
    }
    
    # API代理
    location /api {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    
    # 上传文件代理
    location /uploads {
        proxy_pass http://localhost:3000;
    }
}
```

## 测试脚本

### 数据库连接测试
```bash
node test-db-connection.js
```

### API接口测试
```bash
# 先启动服务器
npm start

# 在另一个终端运行测试
node test-api.js
```

## 部署步骤

### 1. 上传文件到服务器
```bash
# 使用SFTP或宝塔文件管理器上传项目文件到
/var/www/myapp/
```

### 2. 安装依赖
```bash
cd /var/www/myapp
npm install
```

### 3. 初始化数据库
```bash
# 在宝塔面板中执行 database.sql
# 或使用命令行
mysql -u rwww_lisongyu_top -p www_lisongyu_top < database.sql
```

### 4. 配置Nginx
```bash
# 在宝塔面板中添加站点
# 或手动配置nginx.conf
```

### 5. 启动服务
```bash
# 使用PM2管理进程（推荐）
npm install -g pm2
pm2 start server.js --name social-platform
pm2 save
pm2 startup

# 或直接启动
npm start
```

### 6. 配置防火墙
```bash
# 确保以下端口开放
# 80 - HTTP
# 3000 - Node.js（可选，仅用于本地测试）
```

## 功能验证清单

### 基础功能
- [ ] 访问主页 http://101.200.122.44
- [ ] 数据库连接正常
- [ ] API接口响应正常
- [ ] 静态文件加载正常

### 发布动态功能
- [ ] 填写用户名和内容
- [ ] 发布纯文本动态
- [ ] 发布带图片的动态
- [ ] 图片上传成功
- [ ] 动态显示在列表中

### 交互功能
- [ ] 点赞功能正常
- [ ] 取消点赞功能正常
- [ ] 评论功能正常
- [ ] 删除动态功能正常
- [ ] 删除评论功能正常

### 管理功能
- [ ] 访问管理页面
- [ ] 查看统计数据
- [ ] 查看用户列表

## 常见问题排查

### 1. 数据库连接失败
```bash
# 检查MySQL服务状态
systemctl status mysql

# 检查数据库用户权限
mysql -u rwww_lisongyu_top -p

# 测试连接
node test-db-connection.js
```

### 2. API接口无法访问
```bash
# 检查Node.js进程
pm2 list

# 检查端口占用
netstat -tlnp | grep 3000

# 查看日志
pm2 logs social-platform
```

### 3. 图片上传失败
```bash
# 检查uploads目录权限
ls -la uploads/

# 修改权限
chmod 755 uploads/
```

### 4. Nginx 502错误
```bash
# 检查后端服务是否运行
pm2 status

# 检查Nginx配置
nginx -t

# 重启Nginx
systemctl restart nginx
```

## 性能优化建议

### 数据库优化
- 为常用查询字段添加索引
- 定期清理过期数据
- 使用连接池（已配置）

### 后端优化
- 使用PM2集群模式
- 启用Gzip压缩
- 实现缓存机制

### 前端优化
- 图片懒加载
- CDN加速
- 代码压缩

## 安全建议

1. **数据库安全**
   - 使用强密码
   - 限制远程访问
   - 定期备份

2. **API安全**
   - 添加认证机制
   - 实现速率限制
   - 输入验证

3. **文件上传**
   - 限制文件大小（已设置5MB）
   - 验证文件类型
   - 扫描恶意文件

## 监控和日志

### 日志位置
- 应用日志: `pm2 logs social-platform`
- Nginx日志: `/var/log/nginx/`
- 数据库日志: `/var/log/mysql/`

### 监控工具
- PM2监控: `pm2 monit`
- 宝塔面板监控
- 服务器资源监控

## 备份策略

### 数据库备份
```bash
# 每日自动备份
mysqldump -u rwww_lisongyu_top -p www_lisongyu_top > backup_$(date +%Y%m%d).sql
```

### 文件备份
- 定期备份uploads目录
- 备份配置文件
- 使用Git版本控制

## 联系信息
- 服务器IP: 101.200.122.44
- 数据库: www_lisongyu_top
- 管理面板: 宝塔面板
