#!/bin/bash

echo "========================================"
echo "   数据库初始化脚本（Linux 版）"
echo "========================================"
echo

echo "⚠️  请确保 MySQL 服务已启动！"
echo
read -p "按 Enter 继续..."

echo
echo "[1/3] 创建数据库..."
read -s -p "请输入 MySQL root 密码（无密码直接回车）: " MYSQL_PASSWORD
echo

if [ -z "$MYSQL_PASSWORD" ]; then
  mysql -u root -e "CREATE DATABASE IF NOT EXISTS social_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
else
  mysql -u root -p"$MYSQL_PASSWORD" -e "CREATE DATABASE IF NOT EXISTS social_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
fi

if [ $? -ne 0 ]; then
  echo "❌ 数据库创建失败"
  echo "请检查 MySQL 服务是否启动，密码是否正确"
  exit 1
fi
echo "✅ 数据库创建成功"
echo

echo "[2/3] 导入数据库结构..."
if [ -z "$MYSQL_PASSWORD" ]; then
  mysql -u root social_platform < database.sql
else
  mysql -u root -p"$MYSQL_PASSWORD" social_platform < database.sql
fi

if [ $? -ne 0 ]; then
  echo "❌ 数据库导入失败"
  exit 1
fi
echo "✅ 数据库结构导入成功"
echo

echo "[3/3] 验证数据库..."
if [ -z "$MYSQL_PASSWORD" ]; then
  mysql -u root -e "USE social_platform; SHOW TABLES;"
else
  mysql -u root -p"$MYSQL_PASSWORD" -e "USE social_platform; SHOW TABLES;"
fi

echo
echo "========================================"
echo "   数据库初始化完成！"
echo "========================================"
echo
echo "💡 提示："
echo "1. 数据库已包含示例数据"
echo "2. 请确认项目中的数据库账号密码配置正确"
echo