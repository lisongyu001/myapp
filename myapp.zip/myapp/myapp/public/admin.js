// API 基础 URL - 自动检测当前域名（生产环境通过Nginx代理）
const API_BASE_URL = `${window.location.protocol}//${window.location.hostname}/api`;

// 当前激活的标签页
let currentTab = 'posts';

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', () => {
    loadStats();
    loadPosts();
    loadUsers();
});

// ==================== 加载统计数据 ====================
async function loadStats() {
    try {
        const response = await fetch(`${API_BASE_URL}/stats`);
        const result = await response.json();

        if (result.success) {
            document.getElementById('totalPosts').textContent = result.data.posts;
            document.getElementById('totalUsers').textContent = result.data.users;
            document.getElementById('totalComments').textContent = result.data.comments;
            document.getElementById('totalLikes').textContent = result.data.likes;

            // 添加动画效果
            animateValue('totalPosts', 0, result.data.posts, 1000);
            animateValue('totalUsers', 0, result.data.users, 1000);
            animateValue('totalComments', 0, result.data.comments, 1000);
            animateValue('totalLikes', 0, result.data.likes, 1000);
        }
    } catch (error) {
        console.error('加载统计数据失败:', error);
    }
}

// ==================== 数字动画 ====================
function animateValue(id, start, end, duration) {
    const element = document.getElementById(id);
    const range = end - start;
    const increment = range / (duration / 16);
    let current = start;

    const timer = setInterval(() => {
        current += increment;
        if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
            current = end;
            clearInterval(timer);
        }
        element.textContent = Math.floor(current);
    }, 16);
}

// ==================== 切换标签页 ====================
function switchTab(tab) {
    currentTab = tab;

    // 更新标签按钮状态
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');

    // 更新内容显示
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(`${tab}Tab`).classList.add('active');
}

// ==================== 加载帖子列表 ====================
async function loadPosts() {
    const tbody = document.getElementById('postsTableBody');
    tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px;"><div class="loading">加载中...</div></td></tr>';

    try {
        const response = await fetch(`${API_BASE_URL}/posts`);
        const result = await response.json();

        if (result.success && result.data.length > 0) {
            tbody.innerHTML = result.data.map(post => createPostRow(post)).join('');
        } else {
            tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px; color: #666;">暂无数据</td></tr>';
        }
    } catch (error) {
        console.error('加载帖子失败:', error);
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px; color: #ff3b30;">加载失败</td></tr>';
    }
}

// ==================== 创建帖子行 ====================
function createPostRow(post) {
    const avatarContent = post.avatar_url
        ? `<img src="${post.avatar_url}" alt="${post.username}">`
        : post.username.charAt(0).toUpperCase();

    const contentPreview = post.content.length > 50
        ? post.content.substring(0, 50) + '...'
        : post.content;

    const date = new Date(post.created_at).toLocaleString('zh-CN');

    return `
        <tr>
            <td>${post.id}</td>
            <td>
                <span class="table-avatar">${avatarContent}</span>
                ${escapeHtml(post.username)}
            </td>
            <td>${escapeHtml(contentPreview)}</td>
            <td>${post.likes_count || 0}</td>
            <td>${post.comments_count || 0}</td>
            <td>${date}</td>
            <td>
                <button class="action-btn danger" onclick="deletePost(${post.id})">删除</button>
            </td>
        </tr>
    `;
}

// ==================== 删除帖子 ====================
async function deletePost(postId) {
    if (!confirm('确定要删除这条帖子吗？此操作不可恢复！')) {
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/posts/${postId}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.success) {
            showNotification('删除成功', 'success');
            await loadPosts();
            await loadStats();
        } else {
            showNotification(result.message || '删除失败', 'error');
        }
    } catch (error) {
        console.error('删除失败:', error);
        showNotification('删除失败', 'error');
    }
}

// ==================== 加载用户列表 ====================
async function loadUsers() {
    const tbody = document.getElementById('usersTableBody');
    tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 40px;"><div class="loading">加载中...</div></td></tr>';

    try {
        const response = await fetch(`${API_BASE_URL}/users`);
        const result = await response.json();

        if (result.success && result.data.length > 0) {
            tbody.innerHTML = result.data.map(user => createUserRow(user)).join('');
        } else {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 40px; color: #666;">暂无数据</td></tr>';
        }
    } catch (error) {
        console.error('加载用户失败:', error);
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 40px; color: #ff3b30;">加载失败</td></tr>';
    }
}

// ==================== 创建用户行 ====================
function createUserRow(user) {
    const avatarContent = user.avatar_url
        ? `<img src="${user.avatar_url}" alt="${user.username}">`
        : user.username.charAt(0).toUpperCase();

    const date = new Date(user.created_at).toLocaleString('zh-CN');

    return `
        <tr>
            <td>${user.id}</td>
            <td>
                <span class="table-avatar">${avatarContent}</span>
                ${escapeHtml(user.username)}
            </td>
            <td>${date}</td>
            <td><span class="badge success">活跃</span></td>
        </tr>
    `;
}

// ==================== 工具函数 ====================
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        padding: 16px 24px;
        background: ${type === 'success' ? '#34c759' : type === 'error' ? '#ff3b30' : '#007aff'};
        color: white;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 3000;
        animation: slideIn 0.3s ease-out;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// 添加动画样式
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100px);
        }
    }
`;
document.head.appendChild(style);
