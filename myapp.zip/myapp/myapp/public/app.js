// API 基础 URL - 自动检测当前域名（生产环境通过Nginx代理）
const API_BASE_URL = `${window.location.protocol}//${window.location.hostname}/api`;

// 当前用户信息（存储在 localStorage）
let currentUser = {
    username: localStorage.getItem('username') || '',
    avatarUrl: localStorage.getItem('avatarUrl') || ''
};

// 当前选中的帖子ID（用于评论）
let currentPostId = null;

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', () => {
    // 加载用户信息
    if (currentUser.username) {
        document.getElementById('username').value = currentUser.username;
    }
    if (currentUser.avatarUrl) {
        document.getElementById('avatarUrl').value = currentUser.avatarUrl;
    }

    // 加载帖子
    loadPosts();

    // 绑定表单提交
    document.getElementById('postForm').addEventListener('submit', handlePostSubmit);

    // 绑定文件选择
    document.getElementById('imageFile').addEventListener('change', handleFileSelect);

    // 点击模态框外部关闭
    document.getElementById('commentModal').addEventListener('click', (e) => {
        if (e.target.id === 'commentModal') {
            closeCommentModal();
        }
    });
});

// ==================== 文件选择处理 ====================
function handleFileSelect(e) {
    const file = e.target.files[0];
    const preview = document.getElementById('imagePreview');
    const fileName = document.getElementById('fileName');

    if (file) {
        fileName.textContent = file.name;

        // 显示预览
        const reader = new FileReader();
        reader.onload = (e) => {
            preview.innerHTML = `<img src="${e.target.result}" alt="预览">`;
            preview.classList.add('show');
        };
        reader.readAsDataURL(file);
    } else {
        fileName.textContent = '选择图片';
        preview.classList.remove('show');
        preview.innerHTML = '';
    }
}

// ==================== 发布帖子 ====================
async function handlePostSubmit(e) {
    e.preventDefault();

    const username = document.getElementById('username').value.trim();
    const avatarUrl = document.getElementById('avatarUrl').value.trim();
    const content = document.getElementById('content').value.trim();
    const imageFile = document.getElementById('imageFile').files[0];

    if (!username || !content) {
        alert('请填写用户名和内容！');
        return;
    }

    // 保存用户信息到 localStorage
    localStorage.setItem('username', username);
    localStorage.setItem('avatarUrl', avatarUrl);
    currentUser = { username, avatarUrl };

    const submitBtn = document.getElementById('submitBtn');
    submitBtn.disabled = true;
    submitBtn.textContent = '发布中...';

    try {
        const formData = new FormData();
        formData.append('username', username);
        formData.append('avatar_url', avatarUrl);
        formData.append('content', content);
        if (imageFile) {
            formData.append('image', imageFile);
        }

        const response = await fetch(`${API_BASE_URL}/posts`, {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.success) {
            // 清空表单
            document.getElementById('content').value = '';
            document.getElementById('imageFile').value = '';
            document.getElementById('fileName').textContent = '选择图片';
            document.getElementById('imagePreview').classList.remove('show');
            document.getElementById('imagePreview').innerHTML = '';

            // 重新加载帖子
            await loadPosts();

            showNotification('发布成功！', 'success');
        } else {
            showNotification(result.message || '发布失败', 'error');
        }
    } catch (error) {
        console.error('发布失败:', error);
        showNotification('发布失败，请检查网络连接', 'error');
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = `
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="22" y1="2" x2="11" y2="13"/>
                <polygon points="22 2 15 22 11 13 2 9 22 2"/>
            </svg>
            发布动态
        `;
    }
}

// ==================== 加载帖子 ====================
async function loadPosts() {
    const container = document.getElementById('postsContainer');
    container.innerHTML = '<div class="loading">加载中...</div>';

    try {
        const response = await fetch(`${API_BASE_URL}/posts`);
        const result = await response.json();

        if (result.success && result.data.length > 0) {
            container.innerHTML = result.data.map(post => createPostCard(post)).join('');
        } else {
            container.innerHTML = `
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                    </svg>
                    <p>还没有动态，快来发布第一条吧！</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('加载帖子失败:', error);
        container.innerHTML = `
            <div class="empty-state">
                <p>加载失败，请检查服务器是否运行</p>
            </div>
        `;
    }
}

// ==================== 创建帖子卡片 ====================
function createPostCard(post) {
    const timeAgo = getTimeAgo(post.created_at);
    const avatarContent = post.avatar_url
        ? `<img src="${post.avatar_url}" alt="${post.username}">`
        : post.username.charAt(0).toUpperCase();

    return `
        <div class="post-card">
            <div class="post-header">
                <div class="post-avatar">${avatarContent}</div>
                <div class="post-user-info">
                    <div class="post-username">${escapeHtml(post.username)}</div>
                    <div class="post-time">${timeAgo}</div>
                </div>
            </div>
            <div class="post-content">${escapeHtml(post.content)}</div>
            ${post.image_url ? `
                <div class="post-image">
                    <img src="${post.image_url}" alt="帖子图片">
                </div>
            ` : ''}
            <div class="post-actions">
                <button class="btn-icon ${post.liked ? 'active' : ''}" onclick="toggleLike(${post.id})">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="${post.liked ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                    </svg>
                    <span>${post.likes_count || 0}</span>
                </button>
                <button class="btn-icon" onclick="openCommentModal(${post.id})">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                    </svg>
                    <span>${post.comments_count || 0}</span>
                </button>
                <button class="btn-icon post-delete" onclick="deletePost(${post.id})">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="3 6 5 6 21 6"/>
                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                    </svg>
                </button>
            </div>
        </div>
    `;
}

// ==================== 点赞功能 ====================
async function toggleLike(postId) {
    if (!currentUser.username) {
        alert('请先填写用户名！');
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/posts/${postId}/like`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: currentUser.username })
        });

        const result = await response.json();

        if (result.success) {
            await loadPosts();
        }
    } catch (error) {
        console.error('点赞失败:', error);
        showNotification('操作失败', 'error');
    }
}

// ==================== 删除帖子 ====================
async function deletePost(postId) {
    if (!confirm('确定要删除这条动态吗？')) {
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/posts/${postId}`, {
            method: 'DELETE'
        });

        const result = await response.json();

        if (result.success) {
            await loadPosts();
            showNotification('删除成功', 'success');
        } else {
            showNotification(result.message || '删除失败', 'error');
        }
    } catch (error) {
        console.error('删除失败:', error);
        showNotification('删除失败', 'error');
    }
}

// ==================== 评论功能 ====================
async function openCommentModal(postId) {
    currentPostId = postId;
    const modal = document.getElementById('commentModal');
    modal.classList.add('show');

    // 预填用户名
    if (currentUser.username) {
        document.getElementById('commentUsername').value = currentUser.username;
    }

    // 加载评论
    await loadComments(postId);
}

function closeCommentModal() {
    const modal = document.getElementById('commentModal');
    modal.classList.remove('show');
    document.getElementById('commentContent').value = '';
    currentPostId = null;
}

async function loadComments(postId) {
    const container = document.getElementById('commentsList');
    container.innerHTML = '<div class="loading">加载评论中...</div>';

    try {
        const response = await fetch(`${API_BASE_URL}/posts/${postId}/comments`);
        const result = await response.json();

        if (result.success && result.data.length > 0) {
            container.innerHTML = result.data.map(comment => createCommentItem(comment)).join('');
        } else {
            container.innerHTML = '<div class="empty-state"><p>还没有评论</p></div>';
        }
    } catch (error) {
        console.error('加载评论失败:', error);
        container.innerHTML = '<div class="empty-state"><p>加载失败</p></div>';
    }
}

function createCommentItem(comment) {
    const timeAgo = getTimeAgo(comment.created_at);
    const avatarContent = comment.avatar_url
        ? `<img src="${comment.avatar_url}" alt="${comment.username}">`
        : comment.username.charAt(0).toUpperCase();

    return `
        <div class="comment-item">
            <div class="comment-header">
                <div class="comment-avatar">${avatarContent}</div>
                <span class="comment-username">${escapeHtml(comment.username)}</span>
                <span class="comment-time">${timeAgo}</span>
            </div>
            <div class="comment-content">${escapeHtml(comment.content)}</div>
        </div>
    `;
}

async function submitComment() {
    const username = document.getElementById('commentUsername').value.trim();
    const content = document.getElementById('commentContent').value.trim();

    if (!username || !content) {
        alert('请填写用户名和评论内容！');
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/posts/${currentPostId}/comments`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username,
                avatar_url: currentUser.avatarUrl,
                content
            })
        });

        const result = await response.json();

        if (result.success) {
            document.getElementById('commentContent').value = '';
            await loadComments(currentPostId);
            await loadPosts();
            showNotification('评论成功！', 'success');
        } else {
            showNotification(result.message || '评论失败', 'error');
        }
    } catch (error) {
        console.error('评论失败:', error);
        showNotification('评论失败', 'error');
    }
}

// ==================== 工具函数 ====================
function getTimeAgo(dateString) {
    const now = new Date();
    const past = new Date(dateString);
    const diffMs = now - past;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return '刚刚';
    if (diffMins < 60) return `${diffMins}分钟前`;
    if (diffHours < 24) return `${diffHours}小时前`;
    if (diffDays < 7) return `${diffDays}天前`;
    return past.toLocaleDateString('zh-CN');
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showNotification(message, type = 'info') {
    // 简单的通知实现
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        padding: 16px 24px;
        background: ${type === 'success' ? '#34c759' : type === 'error' ? '#ff3b30' : '#007aff'};
        color: white;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 3000;
        animation: slideIn 0.3s ease-out;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// 添加动画样式
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100px);
        }
    }
`;
document.head.appendChild(style);
