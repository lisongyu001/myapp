const http = require('http');

const API_BASE_URL = 'http://localhost:3000/api';

// 颜色输出
const colors = {
    reset: '\x1b[0m',
    green: '\x1b[32m',
    red: '\x1b[31m',
    yellow: '\x1b[33m',
    blue: '\x1b[36m'
};

function log(message, color = 'reset') {
    console.log(`${colors[color]}${message}${colors.reset}`);
}

function makeRequest(method, path, data = null) {
    return new Promise((resolve, reject) => {
        const url = new URL(path, API_BASE_URL);
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            }
        };

        const req = http.request(url, options, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => {
                try {
                    resolve({
                        status: res.statusCode,
                        data: JSON.parse(body)
                    });
                } catch (e) {
                    resolve({
                        status: res.statusCode,
                        data: body
                    });
                }
            });
        });

        req.on('error', reject);

        if (data) {
            req.write(JSON.stringify(data));
        }

        req.end();
    });
}

async function testAPI() {
    log('\n========================================', 'blue');
    log('开始测试 API 接口', 'blue');
    log('========================================\n', 'blue');

    let passedTests = 0;
    let failedTests = 0;

    // 测试1: 获取所有帖子
    try {
        log('测试1: GET /api/posts - 获取所有帖子', 'yellow');
        const response = await makeRequest('GET', '/posts');
        if (response.status === 200 && response.data.success) {
            log(`✓ 通过 - 状态码: ${response.status}, 帖子数量: ${response.data.data.length}`, 'green');
            passedTests++;
        } else {
            log(`✗ 失败 - 状态码: ${response.status}`, 'red');
            failedTests++;
        }
    } catch (error) {
        log(`✗ 失败 - ${error.message}`, 'red');
        failedTests++;
    }

    // 测试2: 获取统计数据
    try {
        log('\n测试2: GET /api/stats - 获取统计数据', 'yellow');
        const response = await makeRequest('GET', '/stats');
        if (response.status === 200 && response.data.success) {
            const stats = response.data.data;
            log(`✓ 通过 - 帖子: ${stats.posts}, 用户: ${stats.users}, 评论: ${stats.comments}, 点赞: ${stats.likes}`, 'green');
            passedTests++;
        } else {
            log(`✗ 失败 - 状态码: ${response.status}`, 'red');
            failedTests++;
        }
    } catch (error) {
        log(`✗ 失败 - ${error.message}`, 'red');
        failedTests++;
    }

    // 测试3: 获取所有用户
    try {
        log('\n测试3: GET /api/users - 获取所有用户', 'yellow');
        const response = await makeRequest('GET', '/users');
        if (response.status === 200 && response.data.success) {
            log(`✓ 通过 - 状态码: ${response.status}, 用户数量: ${response.data.data.length}`, 'green');
            passedTests++;
        } else {
            log(`✗ 失败 - 状态码: ${response.status}`, 'red');
            failedTests++;
        }
    } catch (error) {
        log(`✗ 失败 - ${error.message}`, 'red');
        failedTests++;
    }

    // 测试4: 创建新帖子
    try {
        log('\n测试4: POST /api/posts - 创建新帖子', 'yellow');
        const testData = {
            username: '测试用户',
            avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=test',
            content: '这是一条测试动态，用于验证API接口是否正常工作。'
        };
        const response = await makeRequest('POST', '/posts', testData);
        if (response.status === 200 && response.data.success) {
            log(`✓ 通过 - 帖子ID: ${response.data.data.id}`, 'green');
            passedTests++;
            
            // 测试5: 获取单个帖子
            try {
                log('\n测试5: GET /api/posts/:id - 获取单个帖子', 'yellow');
                const postResponse = await makeRequest('GET', `/posts/${response.data.data.id}`);
                if (postResponse.status === 200 && postResponse.data.success) {
                    log(`✓ 通过 - 帖子内容: ${postResponse.data.data.content.substring(0, 20)}...`, 'green');
                    passedTests++;
                } else {
                    log(`✗ 失败 - 状态码: ${postResponse.status}`, 'red');
                    failedTests++;
                }
            } catch (error) {
                log(`✗ 失败 - ${error.message}`, 'red');
                failedTests++;
            }
        } else {
            log(`✗ 失败 - 状态码: ${response.status}`, 'red');
            failedTests++;
        }
    } catch (error) {
        log(`✗ 失败 - ${error.message}`, 'red');
        failedTests++;
    }

    // 测试6: 获取评论
    try {
        log('\n测试6: GET /api/posts/:id/comments - 获取评论', 'yellow');
        const response = await makeRequest('GET', '/posts/1/comments');
        if (response.status === 200 && response.data.success) {
            log(`✓ 通过 - 评论数量: ${response.data.data.length}`, 'green');
            passedTests++;
        } else {
            log(`✗ 失败 - 状态码: ${response.status}`, 'red');
            failedTests++;
        }
    } catch (error) {
        log(`✗ 失败 - ${error.message}`, 'red');
        failedTests++;
    }

    // 测试7: 点赞功能
    try {
        log('\n测试7: POST /api/posts/:id/like - 点赞功能', 'yellow');
        const response = await makeRequest('POST', '/posts/1/like', { username: '测试用户' });
        if (response.status === 200 && response.data.success) {
            log(`✓ 通过 - ${response.data.message}`, 'green');
            passedTests++;
        } else {
            log(`✗ 失败 - 状态码: ${response.status}`, 'red');
            failedTests++;
        }
    } catch (error) {
        log(`✗ 失败 - ${error.message}`, 'red');
        failedTests++;
    }

    // 测试总结
    log('\n========================================', 'blue');
    log('测试总结', 'blue');
    log('========================================', 'blue');
    log(`总测试数: ${passedTests + failedTests}`, 'blue');
    log(`通过: ${passedTests}`, 'green');
    log(`失败: ${failedTests}`, failedTests > 0 ? 'red' : 'green');
    log('========================================\n', 'blue');

    if (failedTests === 0) {
        log('所有测试通过！API接口工作正常。', 'green');
    } else {
        log('部分测试失败，请检查服务器日志。', 'red');
    }
}

// 检查服务器是否运行
async function checkServer() {
    log('检查服务器是否运行...', 'yellow');
    try {
        await makeRequest('GET', '/stats');
        return true;
    } catch (error) {
        return false;
    }
}

async function main() {
    const serverRunning = await checkServer();
    
    if (!serverRunning) {
        log('错误: 服务器未运行！', 'red');
        log('请先运行: npm start', 'yellow');
        process.exit(1);
    }

    await testAPI();
}

main();
