# 阿里云服务器部署指南

## 前置准备

- 阿里云服务器（已安装宝塔面板）
- 服务器IP: 101.200.122.44
- 已安装 Node.js, MySQL, Nginx
- 项目文件已上传到服务器

---

## 一、宝塔面板配置

### 1.1 添加网站

1. 登录宝塔面板
2. 点击左侧菜单 "网站"
3. 点击 "添加站点"
4. 填写信息：
   - **域名**: 101.200.122.44
   - **根目录**: /www/wwwroot/myapp
   - **FTP**: 不创建
   - **数据库**: 不创建（已有数据库 www_lisongyu_top）
5. 点击 "提交"

### 1.2 配置网站目录

1. 在网站列表中找到 101.200.122.44
2. 点击 "根目录" 链接
3. 确认目录结构：
   ```
   /www/wwwroot/myapp/
   ├── server.js          # 后端服务器
   ├── package.json       # 依赖配置
   ├── uploads/           # 上传文件目录
   └── public/            # 前端静态文件
       ├── index.html
       ├── admin.html
       ├── app.js
       ├── admin.js
       └── styles.css
   ```

### 1.3 设置目录权限

1. 在文件管理器中，右键点击 `uploads` 目录
2. 选择 "权限"
3. 设置为 755：
   - 所有者: 读写执行 (7)
   - 用户组: 读执行 (5)
   - 其他: 读执行 (5)
4. 点击 "确定"

### 1.4 配置Nginx

1. 在网站列表中，点击 "设置" 按钮
2. 选择 "配置文件" 标签
3. 将以下配置复制到 server 块中：

```nginx
server {
    listen 80;
    server_name 101.200.122.44;
    root /www/wwwroot/myapp/public;
    index index.html;

    # API 代理到 Node.js 3000 端口
    location /api {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # 上传文件代理
    location /uploads {
        proxy_pass http://localhost:3000;
    }

    # 静态文件
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Gzip 压缩
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml;
}
```

4. 点击 "保存"
5. 点击 "重载配置"

---

## 二、Node.js 服务部署

### 2.1 安装项目依赖

1. 通过宝塔面板的 "终端" 或 SSH 连接到服务器
2. 进入项目目录：

```bash
cd /www/wwwroot/myapp
```

3. 安装依赖：

```bash
npm install
```

4. 验证安装：

```bash
npm list
```

应该看到以下依赖：
- express
- mysql2
- cors
- multer

### 2.2 测试数据库连接

1. 运行数据库连接测试：

```bash
node test-db-connection.js
```

2. 预期输出：
```
正在测试数据库连接...
配置信息: { host: 'localhost', user: 'www_lisongyu_top', database: 'www_lisongyu_top', password: '***' }
✓ 数据库连接成功！
✓ MySQL版本: 8.0.x
✓ 数据库表: comments, likes, posts, users
✓ 帖子数量: X
✓ 用户数量: X
✓ 连接已关闭

数据库连接测试完成！一切正常。
```

3. 如果失败，检查：
   - MySQL 服务是否运行
   - 数据库用户名和密码是否正确
   - 数据库是否存在

### 2.3 配置PM2（进程管理器）

#### 安装PM2

```bash
npm install -g pm2
```

#### 启动应用

```bash
# 启动应用
pm2 start server.js --name "myapp"

# 查看状态
pm2 status

# 查看日志
pm2 logs myapp

# 设置开机自启
pm2 startup
pm2 save
```

#### 常用PM2命令

```bash
# 查看所有应用
pm2 list

# 查看应用详情
pm2 show myapp

# 重启应用
pm2 restart myapp

# 停止应用
pm2 stop myapp

# 删除应用
pm2 delete myapp

# 监控应用
pm2 monit
```

### 2.4 配置端口防火墙

1. 登录阿里云控制台
2. 进入 ECS 实例管理
3. 点击 "安全组配置"
4. 添加规则：
   - 端口范围: 3000/3000
   - 授权对象: 0.0.0.0/0
   - 协议类型: TCP

5. 在宝塔面板中，点击 "安全" 菜单
6. 添加端口 3000，放行 TCP 协议

---

## 三、数据库配置

### 3.1 创建数据库（如果还未创建）

#### 方法1: 使用宝塔面板

1. 点击 "数据库" 菜单
2. 点击 "添加数据库"
3. 填写信息：
   - 数据库名: www_lisongyu_top
   - 用户名: www_lisongyu_top
   - 密码: lsy@2004
   - 访问权限: 本地服务器
4. 点击 "提交"

#### 方法2: 使用MySQL命令

```bash
# 登录 MySQL
mysql -u root -p

# 执行以下SQL
CREATE DATABASE www_lisongyu_top CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'www_lisongyu_top'@'localhost' IDENTIFIED BY 'lsy@2004';
GRANT ALL PRIVILEGES ON www_lisongyu_top.* TO 'www_lisongyu_top'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 3.2 导入数据库表结构

#### 方法1: 使用 phpMyAdmin

1. 在宝塔面板中，点击 "数据库" 菜单
2. 找到 www_lisongyu_top，点击 "管理" -> "phpMyAdmin"
3. 选择数据库 www_lisongyu_top
4. 点击 "导入" 标签
5. 选择 `database.sql` 文件
6. 点击 "执行"

#### 方法2: 使用命令行

```bash
# 进入项目目录
cd /www/wwwroot/myapp

# 导入数据库
mysql -u www_lisongyu_top -p www_lisongyu_top < database.sql
# 输入密码: lsy@2004
```

### 3.3 验证数据库

```bash
# 连接数据库
mysql -u www_lisongyu_top -p www_lisongyu_top

# 查看表
SHOW TABLES;

# 查看数据
SELECT * FROM users;
SELECT * FROM posts;
SELECT * FROM comments;
SELECT * FROM likes;

# 退出
EXIT;
```

---

## 四、功能测试

### 4.1 测试API接口

1. 确保Node.js服务正在运行：

```bash
pm2 status
```

2. 运行API测试：

```bash
node test-api.js
```

3. 预期输出：所有测试用例通过

### 4.2 浏览器测试

#### 1. 访问主页面

在浏览器中访问：http://101.200.122.44

应该看到：
- ✅ 页面正常加载
- ✅ 显示发布动态表单
- ✅ 显示帖子列表（如果有数据）

#### 2. 测试发布动态（仅文本）

1. 填写用户名：测试用户
2. 填写内容：这是第一条测试动态
3. 点击 "发布动态"
4. 预期结果：
   - ✅ 显示 "发布成功" 通知
   - ✅ 新帖子出现在列表中
   - ✅ 显示正确的时间（刚刚）

#### 3. 测试发布动态（带图片）

1. 填写用户名：测试用户2
2. 填写内容：带图片的动态
3. 点击 "选择图片"，选择一张图片（小于5MB）
4. 查看图片预览
5. 点击 "发布动态"
6. 预期结果：
   - ✅ 图片上传成功
   - ✅ 帖子显示图片
   - ✅ 图片可正常查看

#### 4. 测试点赞功能

1. 点击帖子下方的点赞按钮（心形图标）
2. 预期结果：
   - ✅ 点赞数+1
   - ✅ 图标变为实心（已点赞）
3. 再次点击点赞按钮
4. 预期结果：
   - ✅ 点赞数-1
   - ✅ 图标变为空心（未点赞）

#### 5. 测试评论功能

1. 点击评论按钮（对话框图标）
2. 在弹出的模态框中：
   - 填写用户名
   - 填写评论内容
   - 点击 "发表评论"
3. 预期结果：
   - ✅ 评论成功添加
   - ✅ 评论数+1
   - ✅ 评论显示在列表中

#### 6. 测试删除功能

1. 点击帖子下方的删除按钮（垃圾桶图标）
2. 确认删除
3. 预期结果：
   - ✅ 帖子被删除
   - ✅ 列表自动更新

#### 7. 测试管理后台

访问：http://101.200.122.44/admin.html

应该看到：
- ✅ 统计数据（帖子数、用户数、评论数、点赞数）
- ✅ 用户列表
- ✅ 帖子列表

### 4.3 测试用户信息持久化

1. 发布一条动态，填写用户名
2. 刷新页面
3. 预期结果：
   - ✅ 用户名自动填充到输入框
   - ✅ 头像URL（如果填写）也会保留

---

## 五、故障排查

### 5.1 服务无法访问

#### 症状：浏览器显示 "无法访问此网站"

**排查步骤**：

1. 检查Nginx状态：
```bash
systemctl status nginx
```

2. 检查Node.js服务状态：
```bash
pm2 status
```

3. 检查防火墙：
```bash
# 宝塔面板 -> 安全 -> 检查端口80和3000是否放行

# 阿里云控制台 -> 安全组 -> 检查入站规则
```

4. 测试本地连接：
```bash
curl http://localhost
curl http://localhost:3000/api/posts
```

#### 解决方案：

```bash
# 重启Nginx
systemctl restart nginx

# 重启Node.js服务
pm2 restart myapp

# 检查Nginx配置
nginx -t
```

### 5.2 数据库连接失败

#### 症状：日志显示 "Access denied" 或 "Can't connect to MySQL"

**排查步骤**：

1. 测试MySQL连接：
```bash
mysql -u www_lisongyu_top -p
# 输入密码: lsy@2004
```

2. 检查MySQL服务状态：
```bash
systemctl status mysql
```

3. 检查数据库是否存在：
```bash
mysql -u root -p
SHOW DATABASES;
```

#### 解决方案：

```bash
# 重启MySQL
systemctl restart mysql

# 重新创建数据库用户
mysql -u root -p
CREATE USER 'www_lisongyu_top'@'localhost' IDENTIFIED BY 'lsy@2004';
GRANT ALL PRIVILEGES ON www_lisongyu_top.* TO 'www_lisongyu_top'@'localhost';
FLUSH PRIVILEGES;
```

### 5.3 图片上传失败

#### 症状：发布动态时图片无法上传

**排查步骤**：

1. 检查uploads目录权限：
```bash
ls -la /www/wwwroot/myapp/uploads/
```

2. 查看Node.js日志：
```bash
pm2 logs myapp
```

3. 检查图片大小和类型

#### 解决方案：

```bash
# 修改目录权限
chmod 755 /www/wwwroot/myapp/uploads/
chown -R www:www /www/wwwroot/myapp/uploads/

# 如果权限还是不够，使用777（不推荐生产环境）
chmod 777 /www/wwwroot/myapp/uploads/
```

### 5.4 API请求失败

#### 症状：前端显示 "加载失败" 或 "发布失败"

**排查步骤**：

1. 打开浏览器开发者工具（F12）
2. 查看 Network 标签
3. 检查API请求的状态码
4. 查看 Console 标签的错误信息

#### 常见问题：

- **404 Not Found**: API路径配置错误
- **500 Internal Server Error**: 后端代码错误，查看日志
- **CORS错误**: 检查Nginx配置和CORS中间件

#### 解决方案：

```bash
# 查看详细错误日志
pm2 logs myapp --lines 100

# 检查API配置
# 确保 app.js 中的 API_BASE_URL 正确
```

### 5.5 PM2服务异常

#### 症状：PM2显示应用已停止或错误

**排查步骤**：

1. 查看应用状态：
```bash
pm2 status
pm2 show myapp
```

2. 查看错误日志：
```bash
pm2 logs myapp --err
```

#### 解决方案：

```bash
# 重启应用
pm2 restart myapp

# 删除并重新启动
pm2 delete myapp
pm2 start server.js --name "myapp"

# 清空日志
pm2 flush

# 如果应用崩溃，查看具体错误
pm2 logs myapp --lines 50
```

---

## 六、性能优化

### 6.1 开启Nginx Gzip压缩

在 nginx.conf 的 http 块中添加：

```nginx
gzip on;
gzip_min_length 1k;
gzip_buffers 4 16k;
gzip_comp_level 6;
gzip_types text/plain text/css application/json application/javascript text/xml application/xml;
gzip_vary on;
```

### 6.2 配置静态文件缓存

在 nginx.conf 中添加：

```nginx
location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
    expires 7d;
    add_header Cache-Control "public, immutable";
}
```

### 6.3 PM2集群模式

如果需要更高的性能，可以使用集群模式：

```bash
# 根据CPU核心数启动多个实例
pm2 start server.js -i max --name "myapp"

# 查看集群状态
pm2 list

# 保存配置
pm2 save
```

### 6.4 数据库优化

```sql
-- 添加索引
CREATE INDEX idx_posts_created_at ON posts(created_at);
CREATE INDEX idx_comments_post_id ON comments(post_id);
CREATE INDEX idx_likes_post_id ON likes(post_id);

-- 优化查询
```

---

## 七、安全建议

### 7.1 修改默认密码

- 修改MySQL密码
- 修改宝塔面板密码
- 修改服务器SSH密码

### 7.2 配置防火墙

- 只开放必要的端口（80, 443, 3000）
- 限制SSH访问IP
- 使用fail2ban防止暴力破解

### 7.3 启用HTTPS

1. 在宝塔面板中，点击网站设置
2. 选择 "SSL" 标签
3. 申请Let's Encrypt免费证书
4. 强制HTTPS

### 7.4 定期备份

```bash
# 数据库备份
mysqldump -u www_lisongyu_top -p www_lisongyu_top > backup_$(date +%Y%m%d).sql

# 文件备份
tar -czf backup_$(date +%Y%m%d).tar.gz /www/wwwroot/myapp
```

---

## 八、维护命令

### 日常维护

```bash
# 查看应用状态
pm2 status

# 查看日志
pm2 logs myapp

# 重启应用
pm2 restart myapp

# 查看磁盘使用
df -h

# 查看内存使用
free -h

# 查看进程
ps aux | grep node

# 查看端口占用
netstat -tlnp | grep :3000
```

### 日志管理

```bash
# 清空PM2日志
pm2 flush

# 配置日志轮转
pm2 install pm2-logrotate

# 查看Nginx日志
tail -f /www/server/nginx/logs/access.log
tail -f /www/server/nginx/logs/error.log
```

---

## 九、快速参考

### 项目路径

- 项目根目录: `/www/wwwroot/myapp`
- 后端文件: `/www/wwwroot/myapp/server.js`
- 前端文件: `/www/wwwroot/myapp/public/`
- 上传目录: `/www/wwwroot/myapp/uploads/`

### 服务地址

- 网站: http://101.200.122.44
- 管理后台: http://101.200.122.44/admin.html
- API: http://101.200.122.44/api

### 数据库信息

- 主机: localhost
- 数据库名: www_lisongyu_top
- 用户名: www_lisongyu_top
- 密码: lsy@2004
- 端口: 3306

### 常用命令

```bash
# 启动服务
pm2 start server.js --name "myapp"

# 停止服务
pm2 stop myapp

# 重启服务
pm2 restart myapp

# 查看日志
pm2 logs myapp

# 测试数据库
node test-db-connection.js

# 测试API
node test-api.js
```

---

## 十、联系方式

如遇到问题，请检查：
1. 宝塔面板日志
2. PM2日志
3. Nginx日志
4. MySQL日志

**文档版本**: 1.0  
**更新日期**: 2026年1月18日
