# Node.js 安装和配置指南

## 问题诊断

如果在服务器上执行 `npm` 命令时出现 "command not found" 错误，说明 Node.js 未安装或未正确配置。

---

## 一、检查 Node.js 是否已安装

### 1. 检查 Node.js 版本

```bash
node -v
```

**如果显示版本号**（如 v14.x.x, v16.x.x, v18.x.x 等），说明 Node.js 已安装。

**如果显示 "command not found"**，说明 Node.js 未安装。

### 2. 检查 npm 版本

```bash
npm -v
```

**如果显示版本号**，说明 npm 已安装。

**如果显示 "command not found"**，说明 npm 未安装。

---

## 二、安装 Node.js

### 方法1：使用宝塔面板安装（最简单）

1. 登录宝塔面板
2. 点击左侧菜单的 **"软件商店"**
3. 在搜索框中输入 "nodejs" 或 "node"
4. 找到 "Node.js 版本管理器" 或 "Node.js"
5. 点击 **"安装"**
6. 等待安装完成

**推荐安装版本**：Node.js 16.x 或 18.x（LTS长期支持版本）

### 方法2：使用 NodeSource 仓库安装（推荐）

#### 1. 下载并运行安装脚本

```bash
# 安装 Node.js 18.x（推荐）
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -

# 或者安装 Node.js 16.x
# curl -fsSL https://rpm.nodesource.com/setup_16.x | sudo bash -
```

#### 2. 安装 Node.js

```bash
sudo yum install -y nodejs
```

#### 3. 验证安装

```bash
node -v
npm -v
```

应该显示版本号，例如：
```
v18.17.0
9.6.7
```

### 方法3：使用 NVM（Node Version Manager）安装

NVM 允许你在同一台服务器上安装和管理多个 Node.js 版本。

#### 1. 安装 NVM

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.5/install.sh | bash
```

#### 2. 重新加载配置

```bash
source ~/.bashrc
```

#### 3. 安装 Node.js

```bash
# 安装最新 LTS 版本
nvm install --lts

# 或安装特定版本
nvm install 18.17.0
```

#### 4. 设置默认版本

```bash
nvm use --lts
nvm alias default lts/*
```

#### 5. 验证安装

```bash
node -v
npm -v
```

### 方法4：使用官方二进制包安装

#### 1. 下载 Node.js

```bash
cd /usr/local
sudo wget https://nodejs.org/dist/v18.17.0/node-v18.17.0-linux-x64.tar.xz
```

#### 2. 解压文件

```bash
sudo tar -xJf node-v18.17.0-linux-x64.tar.xz
sudo mv node-v18.17.0-linux-x64 nodejs
```

#### 3. 创建软链接

```bash
sudo ln -s /usr/local/nodejs/bin/node /usr/bin/node
sudo ln -s /usr/local/nodejs/bin/npm /usr/bin/npm
```

#### 4. 验证安装

```bash
node -v
npm -v
```

---

## 三、配置环境变量

如果 Node.js 已安装但 `npm` 命令仍然无法使用，需要配置环境变量。

### 1. 查找 Node.js 安装路径

```bash
which node
which npm
```

如果找到路径，继续下一步。如果没有，需要先安装 Node.js。

### 2. 编辑环境变量配置

```bash
nano ~/.bashrc
```

### 3. 在文件末尾添加以下内容

```bash
export PATH=$PATH:/usr/bin/node
export PATH=$PATH:/usr/local/nodejs/bin
```

**注意**：根据实际的 Node.js 安装路径调整上面的路径。

### 4. 保存并退出

按 `Ctrl + X`，然后按 `Y`，最后按 `Enter` 保存。

### 5. 重新加载配置

```bash
source ~/.bashrc
```

### 6. 验证

```bash
node -v
npm -v
```

---

## 四、安装项目依赖

Node.js 安装完成后，就可以安装项目依赖了。

### 1. 进入项目目录

```bash
cd /www/wwwroot/myapp
```

### 2. 安装依赖

```bash
npm install
```

等待安装完成...

### 3. 验证安装

```bash
npm list
```

应该看到项目依赖列表：
- express
- mysql2
- cors
- multer

---

## 五、常见问题解决

### 问题1：curl 命令不存在

**症状**：执行 `curl` 命令时显示 "command not found"

**解决方法**：
```bash
sudo yum install -y curl
```

### 问题2：wget 命令不存在

**症状**：执行 `wget` 命令时显示 "command not found"

**解决方法**：
```bash
sudo yum install -y wget
```

### 问题3：权限不足

**症状**：执行命令时显示 "Permission denied"

**解决方法**：
```bash
# 在命令前加 sudo
sudo npm install
```

### 问题4：安装速度慢

**症状**：npm install 执行很慢

**解决方法**：使用淘宝镜像
```bash
npm install --registry=https://registry.npmmirror.com
```

或者永久配置：
```bash
npm config set registry https://registry.npmmirror.com
```

### 问题5：npm 版本过低

**症状**：某些包安装失败

**解决方法**：升级 npm
```bash
npm install -g npm@latest
```

### 问题6：Node.js 安装后仍然找不到命令

**症状**：node -v 显示版本，但 npm 命令仍然不可用

**解决方法**：
```bash
# 检查 PATH 环境变量
echo $PATH

# 手动添加 npm 路径
export PATH=$PATH:/usr/local/nodejs/bin

# 永久添加到 .bashrc
echo 'export PATH=$PATH:/usr/local/nodejs/bin' >> ~/.bashrc
source ~/.bashrc
```

---

## 六、验证 Node.js 环境

### 1. 创建测试文件

```bash
cd /tmp
nano test.js
```

### 2. 输入测试代码

```javascript
console.log('Node.js is working!');
console.log('Node version:', process.version);
console.log('NPM version:', require('child_process').execSync('npm -v').toString().trim());
```

保存并退出（Ctrl + X, Y, Enter）。

### 3. 运行测试

```bash
node test.js
```

应该看到：
```
Node.js is working!
Node version: v18.17.0
NPM version: 9.6.7
```

---

## 七、完整的安装流程（推荐）

如果你选择使用宝塔面板 + NVM 的方式，按照以下步骤操作：

### 1. 使用宝塔面板安装基础软件

在宝塔面板中安装：
- Node.js（软件商店 -> 搜索 Node.js -> 安装）
- NVM（如果可用）

### 2. 或使用命令行安装 NVM

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.5/install.sh | bash
source ~/.bashrc
```

### 3. 安装 Node.js

```bash
nvm install --lts
nvm use --lts
nvm alias default lts/*
```

### 4. 验证安装

```bash
node -v
npm -v
```

### 5. 配置淘宝镜像（可选，提高下载速度）

```bash
npm config set registry https://registry.npmmirror.com
```

### 6. 进入项目目录并安装依赖

```bash
cd /www/wwwroot/myapp
npm install
```

---

## 八、安装完成后的下一步

Node.js 安装完成后，继续按照 **SERVER_START_GUIDE.md** 的步骤：

1. 测试数据库连接
2. 启动 Node.js 服务
3. 配置开机自启

---

## 九、快速参考

### 检查安装状态

```bash
node -v
npm -v
```

### 安装命令

**宝塔面板**：软件商店 -> 搜索 Node.js -> 安装

**命令行**：
```bash
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs
```

**使用 NVM**：
```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.5/install.sh | bash
source ~/.bashrc
nvm install --lts
```

### 安装项目依赖

```bash
cd /www/wwwroot/myapp
npm install
```

### 使用淘宝镜像

```bash
npm config set registry https://registry.npmmirror.com
npm install --registry=https://registry.npmmirror.com
```

---

## 十、获取帮助

如果仍然遇到问题，请提供以下信息：

1. 操作系统版本：
   ```bash
   cat /etc/os-release
   ```

2. 当前用户：
   ```bash
   whoami
   ```

3. 查找 Node.js：
   ```bash
   which node
   which npm
   find / -name node 2>/dev/null | head -20
   ```

4. 查看 PATH：
   ```bash
   echo $PATH
   ```

---

**文档版本**: 1.0  
**更新日期**: 2026年1月18日
