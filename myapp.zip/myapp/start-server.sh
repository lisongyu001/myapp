#!/bin/bash

# Node.js 服务启动脚本
# 用于在服务器上启动 Node.js 后端服务

echo "======================================"
echo "  Node.js 服务启动脚本"
echo "======================================"
echo ""

# 检查 PM2 是否安装
if ! command -v pm2 &> /dev/null; then
    echo "❌ PM2 未安装，正在安装..."
    npm install -g pm2
    if [ $? -eq 0 ]; then
        echo "✅ PM2 安装成功"
    else
        echo "❌ PM2 安装失败"
        exit 1
    fi
fi

# 进入项目目录
cd /www/wwwroot/101.200.122.44_80/myapp

# 检查 package.json 是否存在
if [ ! -f "package.json" ]; then
    echo "❌ package.json 文件不存在"
    exit 1
fi

# 检查依赖是否已安装
if [ ! -d "node_modules" ]; then
    echo "📦 正在安装依赖..."
    npm install
    if [ $? -eq 0 ]; then
        echo "✅ 依赖安装成功"
    else
        echo "❌ 依赖安装失败"
        exit 1
    fi
else
    echo "✅ 依赖已安装"
fi

# 检查 uploads 目录
if [ ! -d "uploads" ]; then
    echo "📁 创建 uploads 目录..."
    mkdir -p uploads
    chmod 755 uploads
    echo "✅ uploads 目录已创建"
fi

# 停止旧的服务（如果存在）
echo ""
echo "🛑 停止旧的服务..."
pm2 stop myapp 2>/dev/null
pm2 delete myapp 2>/dev/null

# 启动新服务
echo ""
echo "🚀 启动 Node.js 服务..."
pm2 start server.js --name "myapp"

# 检查服务状态
sleep 2
pm2 status

# 查看日志
echo ""
echo "📋 查看日志（最后20行）："
pm2 logs myapp --lines 20 --nostream

echo ""
echo "======================================"
echo "✅ Node.js 服务已启动"
echo "======================================"
echo ""
echo "服务信息："
echo "  - 应用名称: myapp"
echo "  - 端口: 3000"
echo "  - 状态: 运行中"
echo ""
echo "常用命令："
echo "  查看状态: pm2 status"
echo "  查看日志: pm2 logs myapp"
echo "  重启服务: pm2 restart myapp"
echo "  停止服务: pm2 stop myapp"
echo ""
echo "测试 API："
echo "  curl http://localhost:3000/api/posts"
echo ""
echo "======================================"

# 设置开机自启
echo ""
echo "🔧 配置开机自启..."
pm2 startup
pm2 save

echo "✅ 配置完成"
